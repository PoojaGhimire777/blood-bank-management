import React, { Component } from "react";
import { NavLink } from "react-router-dom";
 
class Contact extends Component {
  render() {
    return (
      <div>
        <div>
            <ul className="header">
              <li><NavLink exact to="/">Home</NavLink></li>
              <li><NavLink to="/stuff">About</NavLink></li>
              <li><NavLink to="/contact">Contact</NavLink></li>
              <li><NavLink to="/Login">Login</NavLink></li>
            </ul> 
        </div>
          <h2>GOT QUESTIONS?</h2>
          <p>The easiest thing to do is to visit in
            our Hospital Or Contact us on our Phone No. #123456789
          </p>
        </div>
    );
  }
}
 
export default Contact;